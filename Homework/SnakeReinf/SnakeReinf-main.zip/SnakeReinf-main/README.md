# SnakeReinf

Reinforcement learning playground with the Snake Game
